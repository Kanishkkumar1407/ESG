package p1;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.nio.file.Paths;
import java.util.Collection;

@SuppressWarnings("serial")
@WebServlet("/uploadDocuments")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10,      // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class UploadDocuments extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/esg_platform";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Lasyasri";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String collegeName = request.getParameter("collegeName");
        Part filePart = null;
        String message = "";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Retrieve the file part and handle exceptions
            filePart = request.getPart("fileUpload"); // Make sure this matches the input field name in the form
            System.out.println("File part: " + filePart);
        } catch (IllegalStateException e) {
            e.printStackTrace();
            message = "<p class='error-message'>File too large. Please upload a smaller file.</p>";
            response.getWriter().write(createResponseHtml(message));
            return;
        } catch (ServletException e) {
            e.printStackTrace();
            message = "<p class='error-message'>An error occurred with the file upload.</p>";
            response.getWriter().write(createResponseHtml(message));
            return;
        } catch (IOException e) {
            e.printStackTrace();
            message = "<p class='error-message'>File upload error. Please try again.</p>";
            response.getWriter().write(createResponseHtml(message));
            return;
        }

        try {
            // Check if college name and file part are not null
            if (collegeName != null && !collegeName.isEmpty() && filePart != null && filePart.getSize() > 0) {
                // Database connection
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

                // Set the file upload directory
                String uploadDirectory = getServletContext().getRealPath("/") + "uploads";
                File uploadDir = new File(uploadDirectory);
                if (!uploadDir.exists()) {
                    uploadDir.mkdir(); // Create the directory if it doesn't exist
                }

                // Save the file on the server
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // Get the filename safely
                String filePath = uploadDirectory + File.separator + fileName;

                try (InputStream fileContent = filePart.getInputStream()) {
                    Files.copy(fileContent, new File(filePath).toPath(), StandardCopyOption.REPLACE_EXISTING);
                }

                // Insert file details into the database (save relative path)
                String relativeFilePath = "uploads/" + fileName; // Save relative path
                String sql = "INSERT INTO documents (college_name, file_path) VALUES (?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, collegeName);
                pstmt.setString(2, relativeFilePath); // Use relative path here
                pstmt.executeUpdate();

                message = "<p class='success-message'>You have successfully uploaded your document!</p>";
            } else {
                message = "<p class='error-message'>Please provide all details and upload a file.</p>";
            }

        } catch (Exception e) {
            e.printStackTrace();
            message = "<p class='error-message'>An error occurred. Please try again later.</p>";
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Set the response content type and display the message
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().write(createResponseHtml(message));
    }

    // Method to create HTML response
    private String createResponseHtml(String message) {
        return "<!DOCTYPE html>"
                + "<html><head><title>Upload ESG Document</title>"
                + "<style>"
                + "body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }"
                + "html, body { height: 100%; margin: 0; display: flex; justify-content: center; align-items: center; }"
                + ".container { text-align: center; }"
                + ".success-message { color: green; font-size: 20px; font-weight: bold; }"
                + ".error-message { color: red; font-size: 18px; }"
                + ".button-container { margin-top: 20px; }"
                + ".dashboard-btn {"
                + "  padding: 10px 20px;"
                + "  background-color: #4CAF50;"
                + "  color: white;"
                + "  border: none;"
                + "  cursor: pointer;"
                + "  font-size: 16px;"
                + "}"
                + ".dashboard-btn:hover {"
                + "  background-color: #45a049;"
                + "}"
                + "</style></head>"
                + "<body>"
                + "<div class='container'>"
                + message
                + "<div class='button-container'>"
                + "<a href='collegedashboard.jsp'><button class='dashboard-btn'>Go Back to Dashboard</button></a>"
                + "</div></div></body></html>";
    }
}
