package p1;

public @interface WebServlet {

}
